#ifndef C2V_H
#define C2V_H

// %P%
// ----- constants ---------------------------------------------------
#pragma ident "$Id: c2v.h 35290 2010-06-11 13:16:27Z Srinivas.Reddy $	20$Date: 2009/05/15 13:59:44 $ NGS"

// ----- standard library --------------------------------------------
// ----- classes, structs, types -------------------------------------
// ----- functions ---------------------------------------------------
double c2v(char* card, int ilatlon);

#endif //~C2V_H

