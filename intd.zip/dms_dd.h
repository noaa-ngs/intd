#ifndef DMS_DD_H
#define DMS_DD_H

#pragma ident "$Id: dms_dd.h 35288 2010-06-11 13:16:19Z Srinivas.Reddy $ NGS"

// ----- local functions ---------------------------------------------
double dms_dd( const char* const dms_str );

#endif // DMS_DD_H
