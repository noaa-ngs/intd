#ifndef EXPFORM_H
#define EXPFORM_H

// %P%
// ----- constants ---------------------------------------------------
#pragma ident "$Id: expform.h 44054 2010-07-12 20:15:52Z bruce.tran $	20$Date: 2009/05/15 15:13:22 $ NGS"

// ----- standard library --------------------------------------------
// ----- classes, structs, types -------------------------------------
// ----- functions ---------------------------------------------------
void expform( void );

#endif //~EXPFORM_H

