#ifndef BB80LL_H
#define BB80LL_H

// %P%
// ----- constants ---------------------------------------------------
#pragma ident "$Id: bb80ll.h 44053 2010-07-12 20:15:48Z bruce.tran $	20$Date: 2009/05/15 15:10:19 $ NGS"

// ----- standard library --------------------------------------------
// ----- classes, structs, types -------------------------------------
// ----- functions ---------------------------------------------------
int bb80ll(char* card, double* lat, double* lon);

#endif //~BB80LL_H

