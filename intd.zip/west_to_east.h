#ifndef WEST_TO_EAST_H
#define WEST_TO_EAST_H

#pragma ident "$Id: west_to_east.h 34376 2010-06-09 21:05:54Z Srinivas.Reddy $	20$Date: 2010/06/03 15:23:55 $ NGS"

// ----- standard library --------------------------------------------
// ----- structures --------------------------------------------------
// ----- local functions ---------------------------------------------
void west_to_east( char* lon );

#endif //~WEST_TO_EAST_H

